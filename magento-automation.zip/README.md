# Magento Sign-Up and Login Automation

This project automates the sign-up and login flows for [Magento Testing Site](https://magento.softwaretestingboard.com/).

## 📌 Features
- BDD with Cucumber
- POM Design Pattern
- Selenium WebDriver (Java)

## 🚀 How to Run
```bash
mvn clean test
```

## 🧪 Scenarios
- User can create a new account
- User can login with valid credentials

## 📂 Folder Structure
- `features/` — Gherkin scenarios
- `pageObjects/` — POM classes
- `stepDefinitions/` — Cucumber step defs
- `runners/` — Test runner
- `evidence/` — Screenshots or video proof
