package stepDefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pageObjects.CreateAccountPage;
import pageObjects.LoginPage;

public class SignupLoginSteps {
    WebDriver driver;
    CreateAccountPage createAccountPage;
    LoginPage loginPage;

    @Given("I open the Magento site")
    public void openSite() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://magento.softwaretestingboard.com/");
    }

    @When("I navigate to Create Account")
    public void goToCreateAccount() {
        driver.findElement(By.linkText("Create an Account")).click();
    }

    @When("I enter valid user details")
    public void enterUserDetails() {
        createAccountPage = new CreateAccountPage(driver);
        String email = "user" + System.currentTimeMillis() + "@test.com";
        createAccountPage.createAccount("John", "Doe", email, "Password123");
    }

    @Then("I should see the account dashboard")
    public void verifyDashboard() {
        assert driver.getTitle().contains("My Account");
        driver.quit();
    }

    @When("I navigate to Sign In")
    public void goToSignIn() {
        driver.findElement(By.linkText("Sign In")).click();
    }

    @When("I enter valid credentials")
    public void enterCredentials() {
        loginPage = new LoginPage(driver);
        loginPage.login("your_registered_email@test.com", "Password123");
    }

    @Then("I should see the user dashboard")
    public void verifyLoginDashboard() {
        assert driver.getTitle().contains("My Account");
        driver.quit();
    }
}
